# citf-public
Official data on the National Covid-​19 Immunisation Programme (PICK) in Malaysia

**Vaccination**
1) vax_malaysia: Daily and cumulative vaccination at country level, as at 2359 of date.
2) vax_state: Daily and cumulative vaccination at state level, as at 2359 of date.

**More datsets will be shared in the coming days.**
